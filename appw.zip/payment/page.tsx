"use client";

import axios from "axios";
import React, { useEffect, useState } from "react";
import "./style.css";
import Link from "next/link";
import Image from "next/image";

const NeuralGlass = () => {
  const [is_login, set_is_login] = useState(false);
  const [email, set_email] = useState("");
  const [is_plane, set_is_plane] = useState(false);

  function getCookie(cname: string) {
    const name = cname + "=";
    const decodedCookie = decodeURIComponent(document.cookie);
    const ca = decodedCookie.split(";");
    for (let c of ca) {
      c = c.trim();
      if (c.indexOf(name) === 0) return c.substring(name.length);
    }
    return "";
  }

  function setCookie(cname: string, cvalue: string, exdays: number) {
    const d = new Date();
    d.setTime(d.getTime() + exdays * 24 * 60 * 60 * 1000);
    const expires = "expires=" + d.toUTCString();
    document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
  }

  useEffect(() => {
    async function validateAlready() {
      const token = getCookie("token");
      if (token) {
        try {
          const res = await axios.post("/api/users/aut/check_token", { token });
          if (res.status === 200) {
            set_is_login(true);
            set_email(res.data.user.email);
          } else {
            set_is_login(false);
            window.location.href = "/register";
          }
        } catch {
          set_is_login(false);
          window.location.href = "/register";
        }
      } else {
        set_is_login(false);
        window.location.href = "/register";
      }
    }

    async function validateAlreadyPay() {
      const token = getCookie("token");
      if (token) {
        try {
          const res = await axios.post("/api/payment/check", { token });
          if (res.status === 200) {
            set_is_plane(true);
          }
        } catch {
          set_is_plane(false);
        }
      } else {
        set_is_plane(false);
      }
    }

    validateAlready();
    validateAlreadyPay();
  }, []);

  const logout = () => {
    setCookie("token", "", 0);
    window.location.href = "/register";
  };
  const hamber = () => {
    const classnameh =
      document.getElementsByClassName("mobile-nav")[0].className;
    if (classnameh.includes("active")) {
      document
        .getElementsByClassName("mobile-nav")[0]
        .classList.remove("active");
    } else {
      document.getElementsByClassName("mobile-nav")[0].classList.add("active");
    }
  };

  return (
    <>
      {/* Backgrounds */}
      <div className="neural-background"></div>
      <div className="geometric-shapes">
        <div className="shape"></div>
        <div className="shape"></div>
        <div className="shape"></div>
        <div className="shape"></div>
      </div>
      <div className="neural-lines">
        <div className="neural-line"></div>
        <div className="neural-line"></div>
        <div className="neural-line"></div>
      </div>

      {/* Header */}
      <header className="glass">
        <nav>
          <Link href="#home" className="logo">
            <svg
              className="logo-icon"
              viewBox="0 0 100 100"
              xmlns="http://www.w3.org/2000/svg"
            >
              <defs>
                <linearGradient
                  id="logoGradient"
                  x1="0%"
                  y1="0%"
                  x2="100%"
                  y2="100%"
                >
                  <stop offset="0%" style={{ stopColor: "#e0a3ff" }} />
                  <stop offset="50%" style={{ stopColor: "#ff69b4" }} />
                  <stop offset="100%" style={{ stopColor: "#9370db" }} />
                </linearGradient>
              </defs>
              <circle
                cx="50"
                cy="30"
                r="8"
                fill="url(#logoGradient)"
                opacity="0.8"
              >
                <animate
                  attributeName="opacity"
                  values="0.8;1;0.8"
                  dur="2s"
                  repeatCount="indefinite"
                />
              </circle>
              <circle
                cx="30"
                cy="60"
                r="6"
                fill="url(#logoGradient)"
                opacity="0.6"
              >
                <animate
                  attributeName="opacity"
                  values="0.6;1;0.6"
                  dur="2.5s"
                  repeatCount="indefinite"
                />
              </circle>
              <circle
                cx="70"
                cy="65"
                r="7"
                fill="url(#logoGradient)"
                opacity="0.7"
              >
                <animate
                  attributeName="opacity"
                  values="0.7;1;0.7"
                  dur="1.8s"
                  repeatCount="indefinite"
                />
              </circle>
              <line
                x1="50"
                y1="30"
                x2="30"
                y2="60"
                stroke="url(#logoGradient)"
                strokeWidth="2"
                opacity="0.6"
              >
                <animate
                  attributeName="opacity"
                  values="0.6;1;0.6"
                  dur="3s"
                  repeatCount="indefinite"
                />
              </line>
              <line
                x1="50"
                y1="30"
                x2="70"
                y2="65"
                stroke="url(#logoGradient)"
                strokeWidth="2"
                opacity="0.6"
              >
                <animate
                  attributeName="opacity"
                  values="0.6;1;0.6"
                  dur="2.2s"
                  repeatCount="indefinite"
                />
              </line>
              <line
                x1="30"
                y1="60"
                x2="70"
                y2="65"
                stroke="url(#logoGradient)"
                strokeWidth="2"
                opacity="0.6"
              >
                <animate
                  attributeName="opacity"
                  values="0.6;1;0.6"
                  dur="2.8s"
                  repeatCount="indefinite"
                />
              </line>
            </svg>
            <div className="d-flex flex-column align-items-center">
              <span>GoodChat</span>
              <span style={{ fontSize: "10px" }}>چت زیبا</span>
            </div>
          </Link>

          <ul className="nav-links d-xl-flex d-none align-items-center">
            <li>
              <Link href="/">خانه</Link>
            </li>

            {is_login && (
              <li>
                <div
                  className="d-flex flex-column align-items-center"
                  style={{ cursor: "pointer" }}
                  onClick={logout}
                >
                  <Image
                    src="/img/log-out.png"
                    alt="Logout"
                    width={20}
                    height={20}
                  />
                </div>
              </li>
            )}

            <li>
              {is_login ? (
                <div className="d-flex flex-column align-items-center">
                  <Image
                    src="/img/person.gif"
                    alt="User"
                    width={30}
                    height={30}
                    style={{ borderRadius: "50px" }}
                  />
                  <span
                    style={{
                      color: "white",
                      fontWeight: "bold",
                      fontSize: "10px",
                    }}
                  >
                    {email}
                  </span>
                </div>
              ) : (
                <Link href="/register">ورود/عضویت</Link>
              )}
            </li>
          </ul>

          <div className="mobile-menu-toggle" onClick={hamber}>
            <div className="hamburger-line"></div>
            <div className="hamburger-line"></div>
            <div className="hamburger-line"></div>
          </div>
        </nav>

        {/* Mobile nav */}
        <div className="mobile-nav">
          <Link href="/">خانه</Link>

          {is_login && (
            <div
              className="d-flex flex-column align-items-center"
              style={{ cursor: "pointer" }}
              onClick={logout}
            >
              <Image
                src="/img/log-out.png"
                alt="Logout"
                width={20}
                height={20}
              />
            </div>
          )}

          {is_login ? (
            <div className="d-flex flex-column align-items-center">
              <Image
                src="/img/person.gif"
                alt="User"
                width={30}
                height={30}
                style={{ borderRadius: "50px" }}
              />
              <span
                style={{ color: "white", fontWeight: "bold", fontSize: "10px" }}
              >
                {email}
              </span>
            </div>
          ) : (
            <Link href="/register">ورود/عضویت</Link>
          )}
        </div>
      </header>

      {/* Pricing Section */}
      {is_plane ? (
        <section className="pricing" id="pricing">
          <h2 className="section-title">تعرفه‌ها</h2>
          <div className="pricing-container">
            <div className="timeline-line"></div>

            {[
              {
                year: "پایه",
                title: "Basic Plan",
                desc: "دسترسی محدود به چت بات فارسی، پاسخگویی سریع به سوالات پایه و تجربه اولیه تعامل با هوش مصنوعی ایرانی.",
                price: "49,000 تومان / ماه",
              },
              {
                year: "استاندارد",
                title: "Standard Plan",
                desc: "دسترسی کامل به ویژگی‌های پایه + پردازش پیشرفته متن، پاسخگویی سریع‌تر و پشتیبانی از چند موضوع همزمان.",
                price: "99,000 تومان / ماه",
              },
              {
                year: "حرفه‌ای",
                title: "Pro Plan",
                desc: "شامل تمام ویژگی‌های استاندارد + پاسخ‌های شخصی‌سازی شده، سرعت پردازش بالا و تعامل هوشمند با چندین کاربر.",
                price: "199,000 تومان / ماه",
              },
              {
                year: "نامحدود",
                title: "Unlimited Plan",
                desc: "دسترسی نامحدود به همه قابلیت‌ها، بدون محدودیت سوال، پشتیبانی ویژه و تجربه کامل هوش مصنوعی ایرانی.",
                price: "399,000 تومان / ماه",
              },
            ].map((plan, idx) => (
              <div className="timeline-item" key={idx}>
                <div className="timeline-content glass">
                  <div className="timeline-year">{plan.year}</div>
                  <h4>{plan.title}</h4>
                  <p>{plan.desc}</p>
                  <p>
                    <strong>قیمت: {plan.price}</strong>
                  </p>
                </div>
                <div className="timeline-dot"></div>
              </div>
            ))}
          </div>
        </section>
      ) : (
        <div
          style={{
            margin: "20%",
            marginTop: "40%",
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          <h3 style={{ color: "white", textAlign: "center" }}>
            پلن شما فعال است و هنوز تمام نشده لطفا به صفحه چت برگردید
          </h3>
          <Link href="/chat" className="glass-btn">
            برگشت به صفحه چت
          </Link>
        </div>
      )}

      {/* Footer */}
      <footer>
        <div className="footer-content">
          <div className="footer-copyright">
            <p>© ۲۰۲۵ Good Chat — تمامی حقوق محفوظ است.</p>
          </div>

          <div className="footer-design">
            طراحی توسط{" "}
            <a
              href="http://arash-moazami-goodarzi.ir/"
              target="_blank"
              rel="noopener noreferrer"
            >
              آرش معظمی گودرزی
            </a>{" "}
            | بهبود یافته با فناوری Good Chat AI |
          </div>

          {/* 🌟 نماد اعتماد الکترونیکی */}
          <div style={{ marginTop: "10px" }}>
            <a
              referrerPolicy="origin"
              target="_blank"
              href="https://trustseal.enamad.ir/?id=659244&Code=jtfCX1mE59GI4Rf0wdVGkUoxNHZmgpgS"
            >
              <img
                referrerPolicy="origin"
                src="https://trustseal.enamad.ir/logo.aspx?id=659244&Code=jtfCX1mE59GI4Rf0wdVGkUoxNHZmgpgS"
                alt="نماد اعتماد الکترونیکی"
                style={{ cursor: "pointer", width: "120px", height: "auto" }}
                data-code="jtfCX1mE59GI4Rf0wdVGkUoxNHZmgpgS"
              />
            </a>
          </div>
        </div>
      </footer>
    </>
  );
};

export default NeuralGlass;
