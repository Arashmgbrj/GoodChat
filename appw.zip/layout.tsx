import './globals.css';
import Preloader from './preloader/Preloader';

export const metadata = {
  title: 'GoodChat / چت زیبا',
  description: 'پلتفرم چت با هوش مصنوعی',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="fa" dir="rtl">
      <head>
        <meta name="enamad" content="2953446" />
      </head>
      <body>
        <Preloader>{children}</Preloader>
      </body>
    </html>
  );
}
