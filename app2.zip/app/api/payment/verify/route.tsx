import { NextResponse } from "next/server";
import { PrismaClient } from "@prisma/client";
import axios from "axios";

const prisma = new PrismaClient();

export async function GET(req: Request) {
  try {
    const url = new URL(req.url);
    const refId = url.searchParams.get("refid") || ""; // PayPing ارسال می‌کند
    const clientRefId = url.searchParams.get("clientrefid") || ""; // همان order_id
    const amount = Number(url.searchParams.get("amount") || 0);

    if (!refId || !amount) {
      return NextResponse.redirect("/payment/status/fail");
    }

    // ✅ Verify پرداخت در PayPing
    const verify = await axios.post(
      "https://api.payping.ir/v2/pay/verify",
      { refId, amount },
      {
        headers: {
          Authorization: `Bearer 0167A5ACEBA0571C14FA0C3F76149C9FF0194A59B87A7FB743F62EC31B8B72E9-1`,
          "Content-Type": "application/json",
        },
      }
    );

    // اگر پاسخ صحیح بود، یعنی پرداخت موفق است
    if (verify.status === 200) {
      // در PayPing فیلد custom در پاسخ Verify بازگردانده نمی‌شود
      // بنابراین برای شناسایی کاربر از clientRefId استفاده می‌کنیم
      const orderParts = clientRefId.split("-");
      const paymentBaseId = orderParts[1];

      const paymentRecord = await prisma.payment_Base.findUnique({
        where: { id: Number(paymentBaseId) },
        include: { user: true },
      });

      if (!paymentRecord || !paymentRecord.user) {
        return NextResponse.redirect("/payment/status/fail");
      }

      const user = paymentRecord.user;
      const plane = Number(paymentRecord.plane);

      // ثبت تراکنش در جدول payment_Finaly
      await prisma.payment_Finaly.create({
        data: {
          userId: user.id,
          plane: paymentRecord.plane,
          trans_id: refId,
          order_id: clientRefId,
          card_holder: verify.data?.cardNumber || "unknown",
          amount: paymentRecord.price,
          np_status: "OK",
        },
      });

      let count = 0;
      if (plane === 1) count = 100;
      else if (plane === 2) count = 200;
      else count = 300;

      const existingDataReq = await prisma.data_req.findFirst({
        where: { userId: user.id },
      });

      if (existingDataReq) {
        await prisma.data_req.update({
          where: { id: existingDataReq.id },
          data: { request_count: existingDataReq.request_count + count },
        });
      } else {
        await prisma.data_req.create({
          data: {
            userId: user.id,
            request_count: count,
          },
        });
      }

      // بروزرسانی وضعیت پرداخت
      await prisma.payment_Base.update({
        where: { id: paymentRecord.id },
        data: { status: "ok" },
      });

      return NextResponse.redirect("https://goodchat.ir/payment/status/sucsuss");
    } else {
      return NextResponse.redirect("https://goodchat.ir/payment/status/fail");
    }
  } catch (error: any) {
    console.error("PayPing verify error:", error.response?.data || error.message);
    return NextResponse.redirect("https://goodchat.ir/payment/status/fail");
  }
}
