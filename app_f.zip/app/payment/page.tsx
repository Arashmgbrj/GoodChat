"use client";

import axios from "axios";
import React, { useEffect, useState } from "react";
import "./style.css";
import Link from "next/link";
import Image from "next/image";

const NeuralGlass = () => {
  const [is_login, set_is_login] = useState(false);
  const [email, set_email] = useState("");
  const [is_plane, set_is_plane] = useState(false);
  const [selectedPlan, setSelectedPlan] = useState<any>(null);
  const [showModal, setShowModal] = useState(false);

  const plans = [
    {
      id:1,
      plan: "پایه",
      title: "Basic Plan",
      text: "دسترسی محدود به چت‌بات فارسی، پاسخگویی سریع و تجربه اولیه هوش مصنوعی ایرانی.",
      req: "100 درخواست",
      price: "100,000تومان",
    },
    {
      id:2,
      plan: "استاندارد",
      title: "Standard Plan",
      text: "پردازش پیشرفته متن، پاسخ سریع‌تر و پشتیبانی از چند موضوع همزمان.",
      req: "400 درخواست",
      price: "400,000 تومان",
    },
    {
      id:3,
      plan: "حرفه‌ای",
      title: "Pro Plan",
      text: "پاسخ‌های شخصی‌سازی شده، سرعت بالا و تعامل چندکاربره.",
      req: "800 درخواست",
      price: "1,000,000 تومان",
    },
  ];

  function getCookie(cname: string) {
    const name = cname + "=";
    const decodedCookie = decodeURIComponent(document.cookie);
    const ca = decodedCookie.split(";");
    for (let c of ca) {
      c = c.trim();
      if (c.indexOf(name) === 0) return c.substring(name.length);
    }
    return "";
  }

  function setCookie(cname: string, cvalue: string, exdays: number) {
    const d = new Date();
    d.setTime(d.getTime() + exdays * 24 * 60 * 60 * 1000);
    const expires = "expires=" + d.toUTCString();
    document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
  }

  useEffect(() => {
    async function validateAlready() {
      const token = getCookie("token");
      if (token) {
        try {
          const res = await axios.post("/api/users/aut/check_token", { token });
          if (res.status === 200) {
            set_is_login(true);
            set_email(res.data.user.email);
          } else {
            set_is_login(false);
            window.location.href = "/register";
          }
        } catch {
          set_is_login(false);
          window.location.href = "/register";
        }
      } else {
        set_is_login(false);
        window.location.href = "/register";
      }
    }

    async function validateAlreadyPay() {
      const token = getCookie("token");
      if (token) {
        try {
          const res = await axios.post("/api/payment/check", { token });
          if (res.status === 200) {
            set_is_plane(true);
          }
        } catch {
          set_is_plane(false);
        }
      } else {
        set_is_plane(false);
      }
    }

    validateAlready();
    validateAlreadyPay();
  }, []);

  const logout = () => {
    setCookie("token", "", 0);
    window.location.href = "/register";
  };

  const hamber = () => {
    const classnameh =
      document.getElementsByClassName("mobile-nav")[0].className;
    if (classnameh.includes("active")) {
      document
        .getElementsByClassName("mobile-nav")[0]
        .classList.remove("active");
    } else {
      document.getElementsByClassName("mobile-nav")[0].classList.add("active");
    }
  };

  const handlePlanClick = async(plan: any) => {
    setSelectedPlan(plan);
    setShowModal(true);

    console.log("Plan clicked:", plan['id']);
    try {

      const token = getCookie("token");

      const res = await axios.post('/api/payment/paying',{token:token,plane:plan['id']})
      if(res.status === 200)
      {
        console.log("ok")
      }
      
    } catch (error) {

      
      
    }

  };

  return (
    <>
      {/* Backgrounds */}
      <div className="neural-background"></div>
      <div className="geometric-shapes">
        <div className="shape"></div>
        <div className="shape"></div>
        <div className="shape"></div>
        <div className="shape"></div>
      </div>
      <div className="neural-lines">
        <div className="neural-line"></div>
        <div className="neural-line"></div>
        <div className="neural-line"></div>
      </div>

      {/* Header */}
      <header className="glass">
        <nav>
          <Link href="#home" className="logo">
            GoodChat
          </Link>
          <ul className="nav-links">
            <li>
              <Link href="/">خانه</Link>
            </li>
            {is_login && (
              <li onClick={logout} style={{ cursor: "pointer" }}>
                خروج
              </li>
            )}
            <li>
              {is_login ? (
                <span>{email}</span>
              ) : (
                <Link href="/register">ورود/عضویت</Link>
              )}
            </li>
          </ul>
          <div className="mobile-menu-toggle" onClick={hamber}></div>
        </nav>
      </header>

      {/* Pricing Section */}
      {is_plane ? (
        <section className="pricing" id="pricing">
          <h2 className="section-title">تعرفه‌ها</h2>
          <div className="pricing-container">
            <div className="timeline-line"></div>
            {plans.map((p, i) => (
              <div
                key={i}
                className="timeline-item"
                style={{
                  display: "flex",
                  flexDirection: "column",
                  cursor: "pointer",
                }}
                onClick={() => handlePlanClick(p)}
              >
                <div className="timeline-content glass">
                  <div className="timeline-year">{p.plan}</div>
                  <h4>{p.title}</h4>
                  <h4>{p.req}</h4>
                  <p>{p.text}</p>
                  <p>
                    <strong>قیمت: {p.price}</strong>
                  </p>
                </div>
                <div className="timeline-dot"></div>
              </div>
            ))}
          </div>
        </section>
      ) : (
        <div style={{ marginTop: "40%", textAlign: "center" }}>
          <h3 style={{ color: "white" }}>
            پلن شما فعال است و هنوز تمام نشده لطفا به صفحه چت برگردید
          </h3>
          <Link href="/chat" className="glass-btn">
            برگشت به صفحه چت
          </Link>
        </div>
      )}

      {/* Modal */}
      {showModal && selectedPlan && (
        <div className="modal-overlay" onClick={() => setShowModal(false)}>
          <div className="modal-content" onClick={(e) => e.stopPropagation()}>
            <h2>اطلاعات پلن</h2>
            <p>
              <strong>نام پلن:</strong> {selectedPlan.plan}
            </p>
            <p>
              <strong>عنوان:</strong> {selectedPlan.title}
            </p>
            <p>
              <strong>تعداد درخواست:</strong> {selectedPlan.req}
            </p>
            <p>
              <strong>قیمت:</strong> {selectedPlan.price}
            </p>
            <p>
              <strong>توضیحات:</strong> {selectedPlan.text}
            </p>
            <button onClick={() => setShowModal(false)}>بستن</button>
          </div>
        </div>
      )}

      {/* Footer */}
      <footer>
        <div className="footer-content">
          <div className="footer-copyright">
            <p>© ۲۰۲۵ Good Chat — تمامی حقوق محفوظ است.</p>
          </div>

          <div className="footer-design">
            طراحی توسط{" "}
            <a
              href="http://arash-moazami-goodarzi.ir/"
              target="_blank"
              rel="noopener noreferrer"
            >
              آرش معظمی گودرزی
            </a>{" "}
            | بهبود یافته با فناوری Good Chat AI |
          </div>

          {/* 🌟 نماد اعتماد الکترونیکی */}
          <div style={{ marginTop: "10px" }}>
            <a
              referrerPolicy="origin"
              target="_blank"
              href="https://trustseal.enamad.ir/?id=659244&Code=jtfCX1mE59GI4Rf0wdVGkUoxNHZmgpgS"
            >
              <img
                referrerPolicy="origin"
                src="https://trustseal.enamad.ir/logo.aspx?id=659244&Code=jtfCX1mE59GI4Rf0wdVGkUoxNHZmgpgS"
                alt="نماد اعتماد الکترونیکی"
                style={{ cursor: "pointer", width: "120px", height: "auto" }}
                data-code="jtfCX1mE59GI4Rf0wdVGkUoxNHZmgpgS"
              />
            </a>
          </div>
        </div>
      </footer>

      {/* Modal CSS */}
      <style jsx>{`
        .modal-overlay {
          position: fixed;
          top: 0;
          left: 0;
          right: 0;
          bottom: 0;
          background: rgba(0, 0, 0, 0.6);
          display: flex;
          align-items: center;
          justify-content: center;
          z-index: 1000;
        }
        .modal-content {
          background: white;
          padding: 20px;
          border-radius: 10px;
          width: 90%;
          max-width: 400px;
          text-align: right;
        }
        .modal-content button {
          margin-top: 10px;
          padding: 5px 10px;
          border: none;
          background: #9370db;
          color: white;
          border-radius: 5px;
          cursor: pointer;
        }
      `}</style>
    </>
  );
};

export default NeuralGlass;
