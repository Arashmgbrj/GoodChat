import "./globals.css";
import "./css/boot.css"; 
import { Metadata } from "next";
import RootLayoutClient from "./RootLayoutClient";
import Script from "next/script";

export const metadata: Metadata = {
  title: "My App",
  description: "Next.js with Bootstrap",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="fa" dir="rtl">
      <head>
        {/* فونت‌ها حذف شدند */}
      </head>
      <body>
        <RootLayoutClient>{children}</RootLayoutClient>

        {/* جاوااسکریپت‌ها با next/script */}
        <Script src="/js/boot.js" strategy="lazyOnload" />
        <Script src="/js/main.js" strategy="lazyOnload" />
      </body>
    </html>
  );
}
