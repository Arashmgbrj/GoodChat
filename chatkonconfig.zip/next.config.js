/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  output: 'standalone', 
  eslint: {
    ignoreDuringBuilds: true,  // هشدارهای eslint باعث fail شدن build نمی‌شوند
  },
};

module.exports = nextConfig;
